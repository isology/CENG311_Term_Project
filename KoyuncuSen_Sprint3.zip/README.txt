---GITHUB PAGE-----
İSMAİL ALPER KOYUNCU 21050111056
https://isology.github.io/CENG311_Term_Project/

ALİ ŞEN 20050111066
https://alisen1907.github.io/sprint3/

---All plugins in index.html (home page)----

--This plugins is for inspecting images
Responsive Touch-enabled Image Lightbox Plugin
https://www.jqueryscript.net/lightbox/Responsive-Touch-enabled-jQuery-Image-Lightbox-Plugin.html

--This is a simple image slider
Powerful and Customizable jQuery Carousel Slider - OWL Carousel
https://www.jqueryscript.net/slider/Powerful-Customizable-jQuery-Carousel-Slider-OWL-Carousel.html

--This is a popup window on page load that is asking users permission
Simple jQuery Plugin For Opening A Popup Window On Page load
https://www.jqueryscript.net/lightbox/Simple-jQuery-Plugin-For-Opening-A-Popup-Window-On-Page-load.html

UI-Widgets are Date Picker Autocompleter both are in contactme.js file